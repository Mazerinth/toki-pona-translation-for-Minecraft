Thank you for trying this pack out! Make sure you change your in-game language to toki pona (ma ali) once the resource pack is loaded.

Translated by jan Masewin - please post feedback and any issues you find at https://github.com/Mazerinth/Minecraft-Toki-Pona-Translation or message Mazerinth#8942 on Discord.

This pack uses two fonts: linja pona by jan Same and David A Roberts (http://musilili.net/linja-pona/), and linja sike by jan Lipamanka for its additional hieroglyphs (https://wyub.github.io/tokipona/linjasike).

The amazing title screen art was made by jan Ronu! Check out his Youtube channel at https://youtube.com/user/Ronu13000

This translation includes some uncommon definitions and pu ala vocabulary. See below:
------------------------
alasa v search
kipisi 1. v cut 2. n piece
      sitelen pona: tilted division sign, %
kin mod very, also
      sitelen pona: exclamation mark with asterisk
leko n block
      sitelen pona: square inside square, ▣
len v conceal
lon v load
ma n world
mani n valuable metal/gem
monsuta n monster, hostile mob
      sitelen pona: horizontal zigzag, vVv
namako mod additional, extra
      sitelen pona: plus sign with missing centre
oko n eye
      sitelen pona: side-view of eye
pake v stop
      sitelen pona: pini minus baseline, T
poki v save, store
powe v trick
      sitelen pona: cross over horizontal line, _x_
soko n mushroom
      sitelen pona: mushroom shape, 🍄