Thank you for trying this pack out! Make sure you change your in-game language to toki pona (ma ali) once the resource pack is loaded.

This translation includes some uncommon definitions and pu ala vocabulary. See below:
- alasa v search
- ante v alter, make changes
- kipisi 1. v cut 2. n piece
- kule prp the colour of...
- leko n block
- len v conceal
- lon v load
- ma n world
- mani n metal/crystal
- monsuta 1. n monster, hostile mob 2. v fear
- pake v stop
- poki v save, store
- powe v trick
- pu n book
- tu v split, halve
- soko 1. n mushroom 2. v explode
- wan v join

Translated by jan Masewin - please post feedback and any issues you find at https://github.com/Mazerinth/Minecraft-Toki-Pona-Translation